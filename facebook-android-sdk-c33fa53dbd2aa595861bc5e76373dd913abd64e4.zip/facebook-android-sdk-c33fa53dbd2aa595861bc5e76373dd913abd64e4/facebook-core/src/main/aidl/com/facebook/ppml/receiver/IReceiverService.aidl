/*
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 * All rights reserved.
 *
 * This source code is licensed under the license found in the
 * LICENSE file in the root directory of this source tree.
 */

package com.facebook.ppml.receiver;

interface IReceiverService {
    int sendEvents(in Bundle eventsBundle);
}
